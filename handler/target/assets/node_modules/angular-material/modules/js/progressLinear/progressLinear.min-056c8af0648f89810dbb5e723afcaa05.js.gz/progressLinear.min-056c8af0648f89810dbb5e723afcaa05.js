/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.9.8
 */
!function(r,e,a){"use strict";function t(r,a,t){function i(r,e,a){return r.attr("aria-valuemin",0),r.attr("aria-valuemax",100),r.attr("role","progressbar"),o}function o(i,o,c){t(o);var s=o[0].querySelector(".md-bar1").style,u=o[0].querySelector(".md-bar2").style,l=e.element(o[0].querySelector(".md-container"));c.$observe("value",function(r){if("query"!=c.mdMode){var e=d(r);o.attr("aria-valuenow",e),u[a.CSS.TRANSFORM]=n[e]}}),c.$observe("mdBufferValue",function(r){s[a.CSS.TRANSFORM]=n[d(r)]}),r(function(){l.addClass("md-ready")})}function d(r){return r>100?100:0>r?0:Math.ceil(r||0)}return{restrict:"E",template:'<div class="md-container"><div class="md-dashed"></div><div class="md-bar md-bar1"></div><div class="md-bar md-bar2"></div></div>',compile:i}}e.module("material.components.progressLinear",["material.core"]).directive("mdProgressLinear",t),t.$inject=["$$rAF","$mdConstant","$mdTheming"];var n=function(){function r(r){var e=r/100,a=(r-100)/2;return"translateX("+a.toString()+"%) scale("+e.toString()+", 1)"}for(var e=new Array(101),a=0;101>a;a++)e[a]=r(a);return e}()}(window,window.angular);
