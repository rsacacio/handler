/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.9.8
 */
!function(i,e,n){"use strict";function r(i){return{restrict:"E",link:i}}e.module("material.components.divider",["material.core"]).directive("mdDivider",r),r.$inject=["$mdTheming"]}(window,window.angular);
